{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "5a8773d4",
   "metadata": {},
   "outputs": [],
   "source": [
    "from animal_shelter import AnimalShelter\n",
    "# now need to create the object from the class\n",
    "shelter = AnimalShelter(\"username\", \"password\")\n",
    "data = {\"age_upon_outcome\":\"1.7 years\",\"animal_type\":\"Cat\"}\n",
    "if shelter.create(data):\n",
    "    print(\"animal added\")\n",
    "else:\n",
    "    print(\"animal not added\")\n",
    "# Read from the object class\n",
    "for document in data:\n",
    "    print(document)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.2"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
